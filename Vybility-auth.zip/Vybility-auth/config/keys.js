

module.exports = {
    mongoURI: 'mongodb+srv://georgi99:gosho123@cluster0-d7cgo.mongodb.net/test?retryWrites=true&w=majority'
};
