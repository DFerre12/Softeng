###############################################################################################################
#----------------------------------            VYBILITY           --------------------------------------------#
#------------------------------                                        ---------------------------------------#
#-----------------------                                                        ------------------------------#
#--------                                                                                             --------#
#---                                                                                                       ---#

                                             Description:

Music app, which generates music playlist based on your mood. You can login, register, logout, take a quz.

Database: MongoDB 


                                            Instalation:

                                            git clone link

                                    node "app.js" in folder "Vybility" 

                                The server will start on PORT: "localhost:5000"

